/* ============================================================
   IGRS — grievance.html page logic
   ============================================================ */

(() => {
  let selectedCategory = null;
  let selectedPriority = null;
  let attachedFiles = [];

  const HIGH_KEYWORDS = ["accident", "fire", "danger", "unsafe", "electrocution", "collapse", "leak", "manhole", "exposed wire"];

  function renderCategoryChips() {
    const wrap = document.getElementById("category-chips");
    wrap.innerHTML = IGRS.CATEGORIES.map(c =>
      `<button type="button" class="chip" data-cat="${c.id}">${c.icon} ${c.label}</button>`
    ).join("");
    wrap.querySelectorAll(".chip").forEach(btn => {
      btn.addEventListener("click", () => selectCategory(btn.dataset.cat));
    });

    // preselect from ?cat= query param
    const params = new URLSearchParams(location.search);
    const preset = params.get("cat");
    if (preset && IGRS.catById(preset)) selectCategory(preset);
  }

  function selectCategory(id) {
    selectedCategory = id;
    document.querySelectorAll("#category-chips .chip").forEach(b => {
      b.classList.toggle("selected", b.dataset.cat === id);
      if (b.dataset.cat === id) b.style.background = "var(--purple-600)", b.style.borderColor = "var(--purple-600)", b.style.color = "#fff";
      else { b.style.background = ""; b.style.borderColor = ""; b.style.color = ""; }
    });
    const cat = IGRS.catById(id);
    document.getElementById("dept-preview").textContent = `Routes to: ${cat.dept}`;
    suggestPriority();
  }

  function suggestPriority() {
    const desc = document.getElementById("description").value.toLowerCase();
    let suggested = "Medium";
    if (selectedCategory === "security" || selectedCategory === "safety") suggested = "High";
    if (HIGH_KEYWORDS.some(k => desc.includes(k))) suggested = "High";
    if (selectedCategory === "parks") suggested = "Low";
    document.getElementById("priority-hint").textContent = `Suggested priority: ${suggested} (based on category & description — you can override).`;
    if (!selectedPriority) applyPriority(suggested, true);
  }

  function applyPriority(p, isSuggestion) {
    selectedPriority = p;
    document.querySelectorAll("#priority-chips .chip").forEach(b => {
      b.classList.toggle("selected", b.dataset.p === p);
    });
    if (!isSuggestion) {
      document.getElementById("priority-hint").textContent = `Priority set to ${p} by you.`;
    }
  }

  function renderUploadList() {
    const list = document.getElementById("upload-list");
    list.innerHTML = attachedFiles.map((f, i) => `
      <div class="upload-item">
        <span>📄 ${f.name} <span class="small-note">(${Math.round(f.size / 1024) || 1} KB)</span></span>
        <button type="button" data-idx="${i}">Remove</button>
      </div>
    `).join("");
    list.querySelectorAll("button").forEach(btn => {
      btn.addEventListener("click", () => {
        attachedFiles.splice(Number(btn.dataset.idx), 1);
        renderUploadList();
      });
    });
  }

  function initUpload() {
    const box = document.getElementById("upload-box");
    const input = document.getElementById("file-input");
    box.addEventListener("click", () => input.click());
    input.addEventListener("change", () => {
      attachedFiles = attachedFiles.concat(Array.from(input.files));
      renderUploadList();
      input.value = "";
    });
  }

  function initPriorityChips() {
    document.querySelectorAll("#priority-chips .chip").forEach(btn => {
      btn.addEventListener("click", () => applyPriority(btn.dataset.p, false));
    });
  }

  function showError(msg) {
    const el = document.getElementById("form-error");
    el.textContent = msg;
    el.style.display = "block";
  }
  function clearError() {
    document.getElementById("form-error").style.display = "none";
  }

  function initSubmit() {
    document.getElementById("grievance-form").addEventListener("submit", e => {
      e.preventDefault();
      clearError();

      const description = document.getElementById("description").value.trim();
      const location = document.getElementById("location").value.trim();
      const name = document.getElementById("name").value.trim();
      const contact = document.getElementById("contact").value.trim();

      if (!selectedCategory) return showError("Please select a category for your grievance.");
      if (!description) return showError("Please describe the issue.");
      if (!location) return showError("Please enter the location of the issue.");
      if (!selectedPriority) applyPriority("Medium", true);

      const c = IGRS.createCase({
        category: selectedCategory,
        description, location,
        priority: selectedPriority || "Medium",
        name, contact,
        files: attachedFiles.map(f => f.name),
      });

      document.getElementById("modal-case-id").textContent = c.id;
      document.getElementById("modal-dept").textContent = `Routed to ${c.dept} · Priority: ${c.priority}`;
      document.getElementById("btn-track-this").href = `track.html?id=${c.id}`;
      IGRSUI.openModal("confirm-modal");
      IGRSUI.toast("Grievance submitted successfully", "success");
    });

    document.getElementById("btn-file-another").addEventListener("click", () => {
      IGRSUI.closeModal("confirm-modal");
      document.getElementById("grievance-form").reset();
      attachedFiles = [];
      selectedCategory = null;
      selectedPriority = null;
      document.getElementById("dept-preview").textContent = "";
      document.getElementById("priority-hint").textContent = "Suggested priority appears once a category is selected.";
      renderUploadList();
      document.querySelectorAll(".chip").forEach(b => { b.classList.remove("selected"); b.style.background = ""; b.style.borderColor = ""; b.style.color = ""; });
      window.scrollTo({ top: 0, behavior: "smooth" });
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    renderCategoryChips();
    initPriorityChips();
    initUpload();
    initSubmit();
    document.getElementById("description").addEventListener("input", suggestPriority);
  });
})();
