/* ============================================================
   IGRS — shared UI behaviours used across every page
   ============================================================ */

const IGRSUI = (() => {

  function initNav() {
    const toggle = document.querySelector(".nav-toggle");
    const links = document.querySelector(".nav-links");
    if (toggle && links) {
      toggle.addEventListener("click", () => links.classList.toggle("open"));
    }
    // highlight active link
    const path = location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll(".nav-links a").forEach(a => {
      if (a.getAttribute("href") === path) a.classList.add("active");
    });
  }

  function toast(message, type = "") {
    let el = document.getElementById("igrs-toast");
    if (!el) {
      el = document.createElement("div");
      el.id = "igrs-toast";
      el.className = "toast";
      document.body.appendChild(el);
    }
    el.textContent = message;
    el.className = `toast show ${type}`;
    clearTimeout(el._t);
    el._t = setTimeout(() => el.classList.remove("show"), 3200);
  }

  function openModal(id) {
    document.getElementById(id)?.classList.add("open");
  }
  function closeModal(id) {
    document.getElementById(id)?.classList.remove("open");
  }
  function initModalClosers() {
    document.querySelectorAll(".modal-backdrop").forEach(bd => {
      bd.addEventListener("click", e => { if (e.target === bd) bd.classList.remove("open"); });
    });
    document.querySelectorAll("[data-close-modal]").forEach(btn => {
      btn.addEventListener("click", () => btn.closest(".modal-backdrop")?.classList.remove("open"));
    });
  }

  function statusStepIndex(status) {
    const flow = IGRS.STATUS_FLOW;
    if (status === "Escalated") return flow.indexOf("InProgress"); // escalated sits mid-flow, flagged separately
    return flow.indexOf(status);
  }

  function fmtDate(iso) {
    return new Date(iso).toLocaleString(undefined, { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
  }

  function timeLeftLabel(c) {
    const overdue = IGRS.isOverdue(c);
    const diffMs = new Date(c.slaDeadline) - new Date();
    const abs = Math.abs(diffMs);
    const hrs = Math.floor(abs / 3600000);
    const mins = Math.floor((abs % 3600000) / 60000);
    const label = hrs >= 24 ? `${Math.floor(hrs / 24)}d ${hrs % 24}h` : `${hrs}h ${mins}m`;
    if (c.status === "Resolved") return "Resolved within SLA window";
    return overdue ? `Overdue by ${label}` : `${label} remaining`;
  }

  /* ---------- printable document generator (Resolution / Progress / Pending report) ---------- */
  function documentKind(c) {
    if (c.status === "Resolved") return "RESOLUTION CERTIFICATE";
    if (c.status === "Escalated") return "ESCALATION & PENDING-REASON REPORT";
    if (c.status === "InProgress" || c.status === "Assigned") return "PROGRESS STATUS REPORT";
    return "ACKNOWLEDGEMENT RECEIPT";
  }

  function pendingReason(c) {
    if (c.status === "Resolved") return "N/A — case resolved.";
    if (c.status === "Escalated") return `SLA deadline of ${fmtDate(c.slaDeadline)} was breached before resolution. Case automatically escalated to the next authority tier for expedited action.`;
    if (c.status === "InProgress") return "Field team assigned and actively working on-site. Awaiting completion and verification.";
    if (c.status === "Assigned") return "Case assigned to the concerned department officer; on-site inspection pending.";
    return "Case registered and awaiting departmental assignment.";
  }

  function generateDocument(c) {
    const cat = IGRS.catById(c.category);
    const kind = documentKind(c);
    const win = window.open("", "_blank", "width=820,height=920");
    if (!win) { toast("Please allow pop-ups to generate the document", "danger"); return; }
    const historyRows = (c.history || []).map(h =>
      `<tr><td>${fmtDate(h.when)}</td><td>${h.what}${h.note ? " — " + h.note : ""}</td></tr>`
    ).join("");

    win.document.write(`
      <html><head><title>${c.id} — ${kind}</title>
      <meta charset="utf-8">
      <style>
        body{ font-family: Georgia, 'Times New Roman', serif; color:#1a1226; padding:48px; max-width:760px; margin:0 auto; }
        .hdr{ display:flex; justify-content:space-between; align-items:center; border-bottom:3px solid #4c1d95; padding-bottom:14px; margin-bottom:22px; }
        .hdr h1{ font-size:18px; margin:0; letter-spacing:.04em; }
        .hdr .seal{ width:56px;height:56px;border-radius:50%; border:2px solid #4c1d95; display:flex; align-items:center; justify-content:center; font-size:11px; text-align:center; color:#4c1d95; font-weight:bold; }
        h2{ font-size:22px; margin:6px 0 2px; }
        .sub{ color:#555; font-size:12.5px; margin-bottom:22px; }
        table.meta{ width:100%; border-collapse:collapse; margin-bottom:22px; }
        table.meta td{ padding:7px 4px; border-bottom:1px solid #ddd; font-size:13px; vertical-align:top; }
        table.meta td.k{ color:#555; width:190px; font-weight:bold; }
        .block{ margin-bottom:20px; }
        .block h3{ font-size:13px; text-transform:uppercase; letter-spacing:.06em; color:#4c1d95; border-bottom:1px solid #ddd; padding-bottom:4px; }
        table.hist{ width:100%; border-collapse:collapse; font-size:12px; }
        table.hist td{ padding:6px 4px; border-bottom:1px solid #eee; vertical-align:top; }
        table.hist td:first-child{ width:170px; color:#555; }
        .footer{ margin-top:40px; display:flex; justify-content:space-between; font-size:11.5px; color:#666; border-top:1px solid #ddd; padding-top:14px; }
        .stamp{ font-size:11px; color:#4c1d95; border:1.5px dashed #4c1d95; padding:8px 14px; transform:rotate(-3deg); border-radius:8px; }
        @media print{ .noprint{ display:none; } }
        .noprint{ text-align:right; margin-bottom:16px; }
        .noprint button{ background:#4c1d95; color:#fff; border:none; padding:10px 18px; border-radius:8px; cursor:pointer; font-size:13px; }
      </style>
      </head><body>
        <div class="noprint"><button onclick="window.print()">Print / Save as PDF</button></div>
        <div class="hdr">
          <div><h1>INTEGRATED GRIEVANCE REDRESSAL SYSTEM</h1><div class="sub">Government Citizen Services Portal</div></div>
          <div class="seal">IGRS<br>OFFICIAL</div>
        </div>
        <h2>${kind}</h2>
        <div class="sub">Document generated on ${fmtDate(new Date().toISOString())}</div>

        <table class="meta">
          <tr><td class="k">Case Reference No.</td><td>${c.id}</td></tr>
          <tr><td class="k">Category</td><td>${cat?.icon || ""} ${cat?.label || c.category}</td></tr>
          <tr><td class="k">Department Routed To</td><td>${c.dept}</td></tr>
          <tr><td class="k">Location</td><td>${c.location}</td></tr>
          <tr><td class="k">Priority</td><td>${c.priority}</td></tr>
          <tr><td class="k">Filed By</td><td>${c.name}</td></tr>
          <tr><td class="k">Date Filed</td><td>${fmtDate(c.createdAt)}</td></tr>
          <tr><td class="k">SLA Deadline</td><td>${fmtDate(c.slaDeadline)}</td></tr>
          <tr><td class="k">Current Status</td><td>${IGRS.STATUS_LABEL[c.status] || c.status}</td></tr>
        </table>

        <div class="block">
          <h3>Grievance Description</h3>
          <p>${c.description}</p>
        </div>

        <div class="block">
          <h3>${c.status === "Resolved" ? "Resolution Note" : "Reason for Pending / Current Action"}</h3>
          <p>${c.status === "Resolved" ? (c.resolutionNote || "Resolved.") : pendingReason(c)}</p>
        </div>

        <div class="block">
          <h3>Case History</h3>
          <table class="hist">${historyRows}</table>
        </div>

        <div class="footer">
          <div>This is a system-generated document from the IGRS portal and does not require a physical signature.</div>
          <div class="stamp">✔ VERIFIED</div>
        </div>
      </body></html>
    `);
    win.document.close();
  }

  return {
    initNav, toast, openModal, closeModal, initModalClosers,
    statusStepIndex, fmtDate, timeLeftLabel, generateDocument, pendingReason, documentKind,
  };
})();

document.addEventListener("DOMContentLoaded", () => {
  IGRSUI.initNav();
  IGRSUI.initModalClosers();
  IGRS.refreshEscalations(IGRS.load());
});
