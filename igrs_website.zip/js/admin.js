/* ============================================================
   IGRS — admin.html page logic
   ============================================================ */

(() => {
  const PASSCODE = "ADMIN123";
  let activeCaseId = null;

  function initGate() {
    const unlocked = sessionStorage.getItem("igrs_admin_unlocked") === "1";
    if (unlocked) showAdmin();

    document.getElementById("btn-unlock").addEventListener("click", tryUnlock);
    document.getElementById("admin-pass").addEventListener("keydown", e => {
      if (e.key === "Enter") tryUnlock();
    });
  }

  function tryUnlock() {
    const val = document.getElementById("admin-pass").value.trim();
    if (val === PASSCODE) {
      sessionStorage.setItem("igrs_admin_unlocked", "1");
      showAdmin();
    } else {
      document.getElementById("gate-error").style.display = "block";
    }
  }

  function showAdmin() {
    document.getElementById("gate-wrap").style.display = "none";
    document.getElementById("admin-content").style.display = "block";
    initFilters();
    render();
  }

  document.addEventListener("click", e => {
    if (e.target.id === "btn-logout") {
      sessionStorage.removeItem("igrs_admin_unlocked");
      document.getElementById("gate-wrap").style.display = "flex";
      document.getElementById("admin-content").style.display = "none";
      document.getElementById("admin-pass").value = "";
    }
  });

  function initFilters() {
    const catSelect = document.getElementById("a-filter-category");
    if (catSelect.children.length === 1) {
      catSelect.innerHTML += IGRS.CATEGORIES.map(c => `<option value="${c.id}">${c.icon} ${c.label}</option>`).join("");
    }
    ["a-search", "a-filter-category", "a-filter-status", "a-filter-priority"].forEach(id => {
      document.getElementById(id).addEventListener("input", render);
      document.getElementById(id).addEventListener("change", render);
    });
    document.getElementById("btn-export-csv").addEventListener("click", () => {
      const cases = IGRS.load();
      IGRS.downloadBlob(IGRS.toCSV(cases), `igrs_cases_export_${Date.now()}.csv`, "text/csv");
      IGRSUI.toast("CSV export downloaded", "success");
    });
  }

  function renderStats(cases) {
    const s = IGRS.stats(cases);
    document.getElementById("a-total").textContent = s.total;
    document.getElementById("a-resolved").textContent = s.resolved;
    document.getElementById("a-pending").textContent = s.pending;
    document.getElementById("a-escalated").textContent = s.escalated;
  }

  function rowHTML(c) {
    const cat = IGRS.catById(c.category);
    return `
      <tr>
        <td class="mono">${c.id}</td>
        <td>${cat?.icon || ""} ${cat?.label || c.category}</td>
        <td>${c.location}</td>
        <td><span class="badge badge-${c.priority.toLowerCase()}">${c.priority}</span></td>
        <td><span class="status-pill status-${c.status}">${IGRS.STATUS_LABEL[c.status]}</span></td>
        <td class="mono" style="font-size:12px; color:${IGRS.isOverdue(c) ? 'var(--danger)' : 'var(--text-faint)'}">${IGRSUI.timeLeftLabel(c)}</td>
        <td><button class="btn btn-sm btn-outline" data-manage="${c.id}">Manage</button></td>
      </tr>`;
  }

  function render() {
    const all = IGRS.refreshEscalations(IGRS.load());
    renderStats(all);

    const search = document.getElementById("a-search").value.trim().toLowerCase();
    const cat = document.getElementById("a-filter-category").value;
    const status = document.getElementById("a-filter-status").value;
    const priority = document.getElementById("a-filter-priority").value;

    const filtered = all.filter(c => {
      if (search && !(c.id.toLowerCase().includes(search) || c.location.toLowerCase().includes(search) || c.description.toLowerCase().includes(search))) return false;
      if (cat && c.category !== cat) return false;
      if (status && c.status !== status) return false;
      if (priority && c.priority !== priority) return false;
      return true;
    });

    const body = document.getElementById("admin-table-body");
    if (!filtered.length) {
      body.innerHTML = `<tr><td colspan="7"><div class="empty-state"><div class="ic">🗂️</div><h3>No cases match</h3><p>Adjust filters to see more cases.</p></div></td></tr>`;
      return;
    }
    body.innerHTML = filtered.map(rowHTML).join("");
    body.querySelectorAll("[data-manage]").forEach(btn => {
      btn.addEventListener("click", () => openManage(btn.dataset.manage));
    });
  }

  function openManage(id) {
    const c = IGRS.getCase(id);
    if (!c) return;
    activeCaseId = id;
    const cat = IGRS.catById(c.category);
    document.getElementById("m-title").textContent = `${c.id} — ${cat?.label || c.category}`;
    document.getElementById("m-sub").textContent = `${c.location} · Filed ${IGRSUI.fmtDate(c.createdAt)} · SLA ${IGRSUI.fmtDate(c.slaDeadline)}`;
    document.getElementById("m-status").value = c.status;
    document.getElementById("m-note").value = c.resolutionNote || "";
    IGRSUI.openModal("manage-modal");
  }

  function initManageModal() {
    document.getElementById("m-save").addEventListener("click", () => {
      if (!activeCaseId) return;
      const newStatus = document.getElementById("m-status").value;
      const note = document.getElementById("m-note").value.trim();
      const c = IGRS.getCase(activeCaseId);
      const prevStatus = c.status;

      const patch = { status: newStatus };
      if (newStatus === "Resolved") patch.resolutionNote = note || "Resolved by admin.";
      else patch.resolutionNote = note;

      let what = `Status changed: ${IGRS.STATUS_LABEL[prevStatus]} → ${IGRS.STATUS_LABEL[newStatus]}`;
      IGRS.updateCase(activeCaseId, patch, { what, note });

      IGRSUI.closeModal("manage-modal");
      IGRSUI.toast(`Case ${activeCaseId} updated`, "success");
      render();
    });

    document.getElementById("m-view-history").addEventListener("click", () => {
      if (!activeCaseId) return;
      const c = IGRS.getCase(activeCaseId);
      document.getElementById("history-case-id").textContent = `${c.id} · ${IGRS.catById(c.category)?.label || c.category}`;
      document.getElementById("history-list").innerHTML = (c.history || []).map(h => `
        <div class="history-item">
          <div class="history-dot"></div>
          <div>
            <div class="when">${IGRSUI.fmtDate(h.when)}</div>
            <div class="what">${h.what}</div>
            ${h.note ? `<div class="note">${h.note}</div>` : ""}
          </div>
        </div>
      `).join("") || `<p class="small-note">No history yet.</p>`;
      IGRSUI.openModal("history-modal");
    });

    document.getElementById("m-doc").addEventListener("click", () => {
      if (!activeCaseId) return;
      const c = IGRS.getCase(activeCaseId);
      if (c) IGRSUI.generateDocument(c);
    });
  }

  document.addEventListener("DOMContentLoaded", () => {
    initGate();
    initManageModal();
  });
})();
