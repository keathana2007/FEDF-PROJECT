/* ============================================================
   IGRS — track.html page logic
   ============================================================ */

(() => {
  function initFilters() {
    const catSelect = document.getElementById("filter-category");
    catSelect.innerHTML += IGRS.CATEGORIES.map(c => `<option value="${c.id}">${c.icon} ${c.label}</option>`).join("");

    const params = new URLSearchParams(location.search);
    const presetId = params.get("id");
    if (presetId) document.getElementById("search-id").value = presetId;

    document.getElementById("search-id").addEventListener("input", render);
    document.getElementById("filter-category").addEventListener("change", render);
    document.getElementById("filter-status").addEventListener("change", render);
    document.getElementById("btn-clear-filters").addEventListener("click", () => {
      document.getElementById("search-id").value = "";
      document.getElementById("filter-category").value = "";
      document.getElementById("filter-status").value = "";
      render();
    });
  }

  function stepperHTML(c) {
    const flow = [
      { key: "Submitted", label: "Submitted" },
      { key: "Assigned", label: "Assigned" },
      { key: "InProgress", label: "In Progress" },
      { key: "Resolved", label: "Resolved" },
    ];
    const currentIndex = c.status === "Escalated" ? 2 : flow.findIndex(f => f.key === c.status);
    return `<div class="stepper">${flow.map((f, i) => {
      let cls = "";
      if (i < currentIndex) cls = "done";
      else if (i === currentIndex) cls = "current";
      return `<div class="step ${cls}"><div class="bar"></div><div class="dot">${i < currentIndex ? "✓" : i + 1}</div><div class="lbl">${f.label}</div></div>`;
    }).join("")}</div>`;
  }

  function escalationHTML(c) {
    const tier = IGRS.escalationTier(c);
    if (c.status !== "Escalated" && tier === 0) return "";
    return `
      <div class="field" style="margin-top:14px;">
        <label>Escalation Flow</label>
        <div class="escalate-flow">
          ${IGRS.ESCALATION_TIERS.map((t, i) => `
            <span class="escalate-node ${i < tier ? "active" : ""}">${t}</span>
            ${i < IGRS.ESCALATION_TIERS.length - 1 ? '<span class="escalate-arrow">→</span>' : ""}
          `).join("")}
        </div>
      </div>`;
  }

  function tokenHTML(c) {
    const cat = IGRS.catById(c.category);
    const priorityClass = `badge-${c.priority.toLowerCase()}`;
    const statusClass = `status-${c.status}`;
    return `
      <div class="token">
        <div class="token-stub">
          <div class="cat-icon">${cat?.icon || "📋"}</div>
          <div class="id">${c.id}</div>
          <div class="token-perf"></div>
        </div>
        <div class="token-body">
          <h4>${cat?.label || c.category} — ${c.location}</h4>
          <div class="token-meta">
            <span class="badge ${priorityClass}">${c.priority}</span>
            <span class="status-pill ${statusClass}">${IGRS.STATUS_LABEL[c.status]}</span>
          </div>
          <p class="token-desc">${c.description}</p>
          ${stepperHTML(c)}
          ${escalationHTML(c)}
          ${c.status === "Resolved" && c.resolutionNote ? `<div class="field" style="margin-top:10px;"><label>Resolution Note</label><p class="token-desc">${c.resolutionNote}</p></div>` : ""}
        </div>
        <div class="token-side">
          <div class="sla-line">Filed on<br><b>${IGRSUI.fmtDate(c.createdAt)}</b></div>
          <div class="sla-line">SLA deadline<br><b>${IGRSUI.fmtDate(c.slaDeadline)}</b></div>
          <div class="sla-line" style="color:${IGRS.isOverdue(c) ? 'var(--danger)' : 'var(--text-dim)'}">${IGRSUI.timeLeftLabel(c)}</div>
          <div class="token-actions">
            <button class="btn btn-sm btn-outline" data-history="${c.id}">History</button>
            <button class="btn btn-sm btn-primary" data-doc="${c.id}">Document</button>
          </div>
        </div>
      </div>`;
  }

  function render() {
    const cases = IGRS.refreshEscalations(IGRS.load());
    const search = document.getElementById("search-id").value.trim().toLowerCase();
    const cat = document.getElementById("filter-category").value;
    const status = document.getElementById("filter-status").value;

    const filtered = cases.filter(c => {
      if (search && !c.id.toLowerCase().includes(search)) return false;
      if (cat && c.category !== cat) return false;
      if (status && c.status !== status) return false;
      return true;
    });

    const list = document.getElementById("case-list");
    if (!filtered.length) {
      list.innerHTML = `<div class="empty-state"><div class="ic">🗂️</div><h3>No matching cases</h3><p>Try a different Case ID or clear your filters.</p></div>`;
      return;
    }
    list.innerHTML = filtered.map(tokenHTML).join("");

    list.querySelectorAll("[data-history]").forEach(btn => {
      btn.addEventListener("click", () => openHistory(btn.dataset.history));
    });
    list.querySelectorAll("[data-doc]").forEach(btn => {
      btn.addEventListener("click", () => {
        const c = IGRS.getCase(btn.dataset.doc);
        if (c) IGRSUI.generateDocument(c);
      });
    });
  }

  function openHistory(id) {
    const c = IGRS.getCase(id);
    if (!c) return;
    document.getElementById("history-case-id").textContent = `${c.id} · ${IGRS.catById(c.category)?.label || c.category}`;
    document.getElementById("history-list").innerHTML = (c.history || []).map(h => `
      <div class="history-item">
        <div class="history-dot"></div>
        <div>
          <div class="when">${IGRSUI.fmtDate(h.when)}</div>
          <div class="what">${h.what}</div>
          ${h.note ? `<div class="note">${h.note}</div>` : ""}
        </div>
      </div>
    `).join("") || `<p class="small-note">No history yet.</p>`;
    IGRSUI.openModal("history-modal");
  }

  document.addEventListener("DOMContentLoaded", () => {
    initFilters();
    render();
  });
})();
