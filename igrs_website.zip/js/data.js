/* ============================================================
   IGRS — shared data layer (localStorage based, no backend)
   ============================================================ */

const IGRS = (() => {
  const STORAGE_KEY = "igrs_cases_v1";

  const CATEGORIES = [
    { id: "electricity", label: "Electricity", icon: "⚡", dept: "Electricity Department (DISCOM)" },
    { id: "road", label: "Road", icon: "🛣️", dept: "Roads & Infrastructure Department" },
    { id: "water", label: "Water", icon: "💧", dept: "Water Supply & Sewerage Department" },
    { id: "municipality", label: "Municipality", icon: "🏛️", dept: "Municipal Corporation" },
    { id: "security", label: "Security", icon: "🛡️", dept: "Public Security & Police Liaison" },
    { id: "parks", label: "Parks", icon: "🌳", dept: "Parks & Horticulture Department" },
    { id: "safety", label: "Safety", icon: "🚧", dept: "Public Safety Department" },
    { id: "amenities", label: "Public Amenities", icon: "🚻", dept: "Public Amenities & Sanitation Department" },
  ];

  const SLA_HOURS = { Low: 168, Medium: 72, High: 24 }; // 7d / 3d / 1d
  const STATUS_FLOW = ["Submitted", "Assigned", "InProgress", "Resolved"];
  const STATUS_LABEL = { Submitted: "Submitted", Assigned: "Assigned", InProgress: "In Progress", Resolved: "Resolved", Escalated: "Escalated" };
  const ESCALATION_TIERS = ["Level 1 — Ward Officer", "Level 2 — Divisional Supervisor", "Level 3 — District Authority"];

  function catById(id) { return CATEGORIES.find(c => c.id === id); }

  function genId() {
    const n = Math.floor(1000 + Math.random() * 9000);
    const t = Date.now().toString().slice(-5);
    return `IGRS-${t}${n}`;
  }

  function load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) { const seeded = seedData(); save(seeded); return seeded; }
      return JSON.parse(raw);
    } catch (e) { return []; }
  }

  function save(cases) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cases));
  }

  function addHistory(c, what, note) {
    c.history = c.history || [];
    c.history.push({ when: new Date().toISOString(), what, note: note || "" });
  }

  function computeDeadline(createdAt, priority) {
    const hrs = SLA_HOURS[priority] || SLA_HOURS.Medium;
    return new Date(new Date(createdAt).getTime() + hrs * 3600 * 1000).toISOString();
  }

  function isOverdue(c) {
    if (c.status === "Resolved") return false;
    return new Date() > new Date(c.slaDeadline);
  }

  function escalationTier(c) {
    if (!isOverdue(c)) return 0;
    const overdueHours = (Date.now() - new Date(c.slaDeadline).getTime()) / 3600000;
    const step = SLA_HOURS[c.priority] || SLA_HOURS.Medium;
    if (overdueHours > step * 2) return 3;
    if (overdueHours > step) return 2;
    return 1;
  }

  function refreshEscalations(cases) {
    let changed = false;
    cases.forEach(c => {
      if (c.status !== "Resolved" && isOverdue(c) && c.status !== "Escalated") {
        c.status = "Escalated";
        addHistory(c, "Auto-escalated — SLA deadline breached", `Escalated to ${ESCALATION_TIERS[escalationTier(c) - 1] || ESCALATION_TIERS[0]}`);
        changed = true;
      }
    });
    if (changed) save(cases);
    return cases;
  }

  function createCase({ category, description, location, priority, name, contact, files }) {
    const cases = load();
    const now = new Date().toISOString();
    const c = {
      id: genId(),
      category, description, location, priority,
      name: name || "Anonymous Citizen",
      contact: contact || "—",
      dept: catById(category)?.dept || "General Grievance Cell",
      status: "Submitted",
      createdAt: now,
      slaDeadline: computeDeadline(now, priority),
      files: files || [],
      resolutionNote: "",
      history: [],
    };
    addHistory(c, "Grievance submitted by citizen", `Routed to ${c.dept}`);
    cases.unshift(c);
    save(cases);
    return c;
  }

  function getCase(id) { return load().find(c => c.id === id); }

  function updateCase(id, patch, historyNote) {
    const cases = load();
    const idx = cases.findIndex(c => c.id === id);
    if (idx === -1) return null;
    Object.assign(cases[idx], patch);
    if (historyNote) addHistory(cases[idx], historyNote.what, historyNote.note);
    save(cases);
    return cases[idx];
  }

  function seedData() {
    const mk = (category, description, location, priority, status, hoursAgo, note) => {
      const created = new Date(Date.now() - hoursAgo * 3600 * 1000).toISOString();
      const c = {
        id: genId(), category, description, location, priority,
        name: "Citizen Record", contact: "—",
        dept: catById(category)?.dept || "General Grievance Cell",
        status, createdAt: created, slaDeadline: computeDeadline(created, priority),
        files: [], resolutionNote: note || "", history: [],
      };
      addHistory(c, "Grievance submitted by citizen", `Routed to ${c.dept}`);
      if (status !== "Submitted") addHistory(c, "Assigned to field officer", "");
      if (status === "InProgress") addHistory(c, "Work in progress", "Crew dispatched to site");
      if (status === "Resolved") { addHistory(c, "Marked Resolved", note); }
      if (status === "Escalated") addHistory(c, "Auto-escalated — SLA deadline breached", "Escalated to Level 2 — Divisional Supervisor");
      return c;
    };
    return [
      mk("water", "No water supply in Sector 12 for 3 days.", "Sector 12, Ward 4", "High", "Escalated", 48, ""),
      mk("road", "Large pothole near school causing accidents.", "MG Road, near Govt. School", "High", "InProgress", 10, ""),
      mk("electricity", "Streetlights not working on entire lane.", "Lane 5, Shastri Nagar", "Medium", "Assigned", 20, ""),
      mk("parks", "Broken swings and unsafe play equipment.", "Nehru Park, Block C", "Low", "Submitted", 5, ""),
      mk("municipality", "Garbage not collected for over a week.", "Ward 9 Market Road", "Medium", "Resolved", 90, "Collection route corrected; municipal van rescheduled to daily pickup at 7 AM."),
      mk("safety", "Open manhole without barricade, safety hazard.", "Ring Road Junction", "High", "Resolved", 60, "Manhole cover replaced and barricade removed after cover installation. Verified by field inspector."),
      mk("security", "Inadequate street lighting causing safety concerns at night.", "Old Bus Stand area", "Medium", "Submitted", 2, ""),
      mk("amenities", "Public toilet facility non-functional and unhygienic.", "Central Bus Terminus", "Medium", "InProgress", 15, ""),
    ];
  }

  function stats(cases) {
    const total = cases.length;
    const resolved = cases.filter(c => c.status === "Resolved").length;
    const pending = cases.filter(c => !["Resolved"].includes(c.status)).length;
    const escalated = cases.filter(c => c.status === "Escalated").length;
    return { total, resolved, pending, escalated };
  }

  function toCSV(cases) {
    const headers = ["Case ID", "Category", "Department", "Location", "Priority", "Status", "Filed On", "SLA Deadline", "Resolution Note"];
    const rows = cases.map(c => [
      c.id, catById(c.category)?.label || c.category, c.dept, c.location, c.priority,
      STATUS_LABEL[c.status] || c.status, new Date(c.createdAt).toLocaleString(),
      new Date(c.slaDeadline).toLocaleString(), (c.resolutionNote || "").replace(/[\r\n,]+/g, " "),
    ]);
    return [headers, ...rows].map(r => r.map(f => `"${String(f).replace(/"/g, '""')}"`).join(",")).join("\n");
  }

  function downloadBlob(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  }

  return {
    CATEGORIES, SLA_HOURS, STATUS_FLOW, STATUS_LABEL, ESCALATION_TIERS,
    catById, genId, load, save, addHistory, computeDeadline, isOverdue, escalationTier,
    refreshEscalations, createCase, getCase, updateCase, stats, toCSV, downloadBlob,
  };
})();
