# IGRS — Integrated Grievance Redressal System

A front-end demo of a citizen grievance portal, built with plain HTML, CSS and JavaScript (no build tools, no backend — data is stored in your browser's `localStorage`).

## Files

```
igrs/
├── index.html          Home page — hero, live stats, category grid
├── grievance.html       User module: grievance submission form
├── track.html            User module: status tracking, SLA, escalation, documents
├── admin.html            Admin module: case management, resolution, export
├── css/
│   └── style.css         Shared purple/black design system
├── js/
│   ├── data.js            Shared data layer (categories, SLA rules, escalation, storage)
│   ├── main.js            Shared UI helpers (nav, toasts, modals, document generator)
│   ├── grievance.js       Logic for grievance.html
│   ├── track.js           Logic for track.html
│   └── admin.js           Logic for admin.html
└── README.md
```

## How to run

No installation needed.

1. Unzip the folder.
2. Double-click `index.html` to open it in your browser — **or**, for the most reliable experience (especially with `localStorage` shared across pages), serve the folder locally:
   ```
   cd igrs
   python3 -m http.server 8000
   ```
   then visit `http://localhost:8000`.

## What's included

- **Grievance Form** with 8 categories: Electricity, Road, Water, Municipality, Security, Parks, Safety, Public Amenities.
- **Automatic department routing** based on category.
- **Priority badges** (Low / Medium / High) with an auto-suggestion the citizen can override.
- **Status tracking** with a visual stepper: Submitted → Assigned → In Progress → Resolved.
- **SLA display** — deadline shown per case, countdown/overdue indicator.
- **Escalation flow** — cases that miss their SLA deadline automatically escalate through 3 authority tiers, shown as a flow diagram.
- **Admin panel** (demo passcode: `ADMIN123`) to filter/search cases, update status, add resolution notes, and view full history.
- **Document export** — every case (resolved, in progress, or pending) can generate a printable status document explaining what happened and, if pending, why — use "Print / Save as PDF" in the generated window.
- **CSV export** of all cases from the admin panel.

## Notes

- This is a demo/prototype: the admin passcode is client-side only and not secure — replace with real authentication before any production use.
- Sample cases are seeded automatically the first time you open the app so the UI isn't empty; clear your browser's site data to reset.
